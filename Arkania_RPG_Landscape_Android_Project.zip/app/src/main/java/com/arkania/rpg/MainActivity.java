package com.arkania.rpg;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        game = new GameView(this);
        setContentView(game);
    }
}

class GameView extends View {
    Paint p = new Paint(3);
    float px=0, py=0, camX=0, camY=0;
    float joyX=0, joyY=0;
    boolean attacking=false;
    int level=1, hp=100, maxHp=100, exp=0, gold=40, quest=0;
    long last=System.currentTimeMillis();
    ArrayList<Enemy> enemies=new ArrayList<>();
    Random rnd=new Random(8);

    GameView(Context c) {
        super(c);
        setFocusable(true);
        for(int i=0;i<22;i++) enemies.add(new Enemy(rnd.nextFloat()*1800-900,rnd.nextFloat()*1100-550));
    }

    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        // sky/ground
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(22,35,52)); c.drawRect(0,0,w,h,p);
        p.setColor(Color.rgb(55,92,61));
        c.drawRect(0,h*.42f,w,h,p);

        camX += (px-camX)*.12f; camY += (py-camY)*.12f;
        drawWorld(c,w,h);
        drawPlayer(c,w/2,h/2);
        drawHUD(c,w,h);
        drawControls(c,w,h);

        invalidate();
    }

    void drawWorld(Canvas c,float w,float h){
        // grid / paths
        p.setColor(Color.argb(35,255,255,255)); p.setStrokeWidth(2);
        for(int x=-1000;x<=1000;x+=100) {
            float sx=w/2+(x-camX)*.65f;
            c.drawLine(sx, h*.42f, sx, h, p);
        }
        for(int y=-600;y<=600;y+=100) {
            float sy=h*.62f+(y-camY)*.32f;
            c.drawLine(0,sy,w,sy,p);
        }

        // lake
        float lx=w/2+(-520-camX)*.65f, ly=h*.62f+(-180-camY)*.32f;
        p.setColor(Color.rgb(38,105,145)); c.drawOval(lx-230,ly-90,lx+230,ly+90,p);

        // village
        drawBuilding(c, w/2+(-260-camX)*.65f,h*.62f+(-40-camY)*.32f,"VILLAGE");
        drawBuilding(c, w/2+(120-camX)*.65f,h*.62f+(-130-camY)*.32f,"SHOP");
        drawBuilding(c, w/2+(380-camX)*.65f,h*.62f+(170-camY)*.32f,"TOWER");

        for(int i=0;i<18;i++){
            float x=(i*211%1800)-900, y=(i*137%1000)-500;
            drawTree(c,w/2+(x-camX)*.65f,h*.62f+(y-camY)*.32f);
        }

        for(Enemy e: enemies) {
            float dx=e.x-camX, dy=e.y-camY;
            if(Math.abs(dx)<1300 && Math.abs(dy)<900) {
                drawEnemy(c,w/2+dx*.65f,h*.62f+dy*.32f,e);
            }
        }
        // NPCs
        drawNpc(c,w/2+(-90-camX)*.65f,h*.62f+(-15-camY)*.32f,"Rian");
        drawNpc(c,w/2+(70-camX)*.65f,h*.62f+(-35-camY)*.32f,"Mira");
    }

    void drawTree(Canvas c,float x,float y){
        p.setColor(Color.rgb(91,61,37)); c.drawRect(x-8,y,x+8,y+45,p);
        p.setColor(Color.rgb(36,112,57)); c.drawCircle(x,y-5,32,p);
        p.setColor(Color.rgb(48,137,67)); c.drawCircle(x-18,y+8,23,p);
        c.drawCircle(x+18,y+8,23,p);
    }
    void drawBuilding(Canvas c,float x,float y,String s){
        p.setColor(Color.rgb(122,83,55)); c.drawRect(x-48,y-40,x+48,y+35,p);
        Path roof=new Path(); roof.moveTo(x-60,y-40); roof.lineTo(x,y-82); roof.lineTo(x+60,y-40); roof.close();
        p.setColor(Color.rgb(112,48,48)); c.drawPath(roof,p);
        p.setTextSize(16); p.setColor(Color.WHITE); c.drawText(s,x-42,y+60,p);
    }
    void drawNpc(Canvas c,float x,float y,String name){
        p.setColor(Color.rgb(237,184,125)); c.drawCircle(x,y-28,15,p);
        p.setColor(Color.rgb(65,78,145)); c.drawRect(x-18,y-12,x+18,y+34,p);
        p.setColor(Color.WHITE); p.setTextSize(15); c.drawText(name,x-18,y-48,p);
    }
    void drawEnemy(Canvas c,float x,float y,Enemy e){
        p.setColor(Color.rgb(180,55,55)); c.drawCircle(x,y-18,19,p);
        p.setColor(Color.rgb(115,38,45)); c.drawRect(x-22,y,x+22,y+36,p);
        p.setColor(Color.BLACK); c.drawCircle(x-7,y-21,3,p); c.drawCircle(x+7,y-21,3,p);
        p.setColor(Color.RED); c.drawRect(x-20,y-48,x+20,y-43,p);
        p.setColor(Color.GREEN); c.drawRect(x-20,y-48,x-20+40*e.hp/3f,y-43,p);
    }
    void drawPlayer(Canvas c,float x,float y){
        p.setColor(Color.rgb(225,172,115)); c.drawCircle(x,y-38,20,p);
        p.setColor(Color.rgb(46,72,142)); c.drawRect(x-23,y-18,x+23,y+45,p);
        p.setColor(Color.rgb(170,185,205)); c.drawRect(x-35,y-5,x-23,y+40,p);
        p.setColor(Color.rgb(220,220,230)); c.drawRect(x+23,y-5,x+35,y+40,p);
        p.setColor(Color.WHITE); p.setTextSize(16); c.drawText("KAEL",x-18,y-66,p);
    }
    void drawHUD(Canvas c,float w,float h){
        p.setColor(Color.argb(215,12,18,28)); c.drawRoundRect(18,18,330,105,18,18,p);
        p.setColor(Color.WHITE); p.setTextSize(19); c.drawText("KAEL  •  LV "+level,34,45,p);
        p.setColor(Color.DKGRAY); c.drawRect(34,58,300,72,p);
        p.setColor(Color.RED); c.drawRect(34,58,34+266*hp/(float)maxHp,72,p);
        p.setColor(Color.rgb(70,130,220)); c.drawRect(34,79,34+266*exp/100f,91,p);
        p.setColor(Color.WHITE); p.setTextSize(15); c.drawText("HP "+hp+"/"+maxHp+"    EXP "+exp+"%    Gold "+gold,34,104,p);
        p.setColor(Color.argb(225,12,18,28)); c.drawRoundRect(w-300,18,w-18,105,18,18,p);
        p.setColor(Color.WHITE); p.setTextSize(16);
        c.drawText("QUEST: "+(quest==0?"Hutan Terlarang":"Kalahkan 5 Monster"),w-282,48,p);
        c.drawText("Lokasi: "+(Math.round(px))+", "+Math.round(py),w-282,75,p);
        c.drawText("Tujuan: Temui Rian di desa",w-282,98,p);
        if(attacking){
            p.setTextSize(22); p.setColor(Color.YELLOW); c.drawText("⚔ SERANGAN!",w/2-65,135,p);
        }
    }
    void drawControls(Canvas c,float w,float h){
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(80,255,255,255)); c.drawCircle(110,h-105,78,p);
        p.setColor(Color.argb(130,255,255,255)); c.drawCircle(110+joyX*48,h-105+joyY*48,30,p);
        p.setColor(Color.argb(120,180,55,55)); c.drawCircle(w-105,h-105,72,p);
        p.setColor(Color.WHITE); p.setTextSize(22); c.drawText("ATK",w-128,h-98,p);
        p.setColor(Color.argb(100,255,255,255)); c.drawCircle(w-215,h-65,42,p);
        p.setColor(Color.WHITE); p.setTextSize(15); c.drawText("MAP",w-235,h-60,p);
    }

    public boolean onTouchEvent(android.view.MotionEvent e){
        float x=e.getX(), y=e.getY(), w=getWidth(), h=getHeight();
        if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
            if(x<250 && y>h-210){
                float dx=x-110, dy=y-(h-105);
                float len=(float)Math.sqrt(dx*dx+dy*dy); if(len<1)len=1;
                joyX=Math.max(-1,Math.min(1,dx/78)); joyY=Math.max(-1,Math.min(1,dy/78));
            } else if(x>w-200 && y>h-190){
                attack();
            }
        } else if(e.getAction()==MotionEvent.ACTION_UP){
            joyX=joyY=0;
        }
        return true;
    }
    void attack(){
        attacking=true;
        for(Enemy e: enemies){
            float d=(float)Math.hypot(e.x-px,e.y-py);
            if(d<170 && e.hp>0){
                e.hp=0; exp+=25; gold+=12;
                if(exp>=100){exp-=100; level++; maxHp+=15; hp=maxHp;}
                quest=Math.min(5,quest+1);
            }
        }
        postDelayed(()->attacking=false,220);
    }
    class Enemy {
        float x,y; int hp=3;
        Enemy(float a,float b){x=a;y=b;}
    }
}
