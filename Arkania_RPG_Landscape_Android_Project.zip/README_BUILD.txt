ARKANIA RPG — LANDSCAPE ANDROID PROJECT

Fitur:
- Forced landscape / horizontal orientation
- Full-screen mobile UI
- Touch joystick + attack button
- Large explorable coordinate world
- Village, shop, tower, lake, forest
- Kael player character
- NPC Rian and Mira
- Monsters and combat
- EXP, level, HP and gold
- Quest HUD

Cara build:
1. Buka folder ini di Android Studio.
2. Pastikan Android SDK 35 dan Android SDK Build-Tools terpasang.
3. Tunggu Gradle Sync selesai.
4. Build > Build APK(s).
5. APK debug akan berada di app/build/outputs/apk/debug/app-debug.apk

Catatan: project ini sengaja tidak mengklaim sebagai game 3D AAA. Renderer menggunakan Android Canvas agar dapat dibangun tanpa engine eksternal.
